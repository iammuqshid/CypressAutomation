describe('My Test Suite', () => {
    it('Verify Page Title of the Page', () => {
      cy.visit('https://the-internet.herokuapp.com/')
      cy.title().should('eq','The internet')
    })
  })